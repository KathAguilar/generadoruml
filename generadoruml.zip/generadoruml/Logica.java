package generadoruml;

public class Logica {
    
}
