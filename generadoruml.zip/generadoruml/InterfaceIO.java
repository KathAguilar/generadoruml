package generadoruml;

public interface InterfaceIO {
    String leer(String mensaje);
    void mostrar(String mensaje);
}
