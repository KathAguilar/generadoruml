
package generadoruml;

public class GeneradorJava {
    
}
