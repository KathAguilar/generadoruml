package generadoruml;

public class Main {

    public static void main(String[] args) {
       Control control = new Control();
       control.iniciar();
    }   

}