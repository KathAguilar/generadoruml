
package generadoruml;

public class GeneradorUML {
 public void organizarUML(Modelo modelo){
     //estructura uml
 }   
}
